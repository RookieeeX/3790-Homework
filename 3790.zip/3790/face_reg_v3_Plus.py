import os
from PIL import Image
import numpy as np

# 设置数据路径和图片尺寸
dataset_path = r"C:\Users\34800\Desktop\3790 essay\training_dataset"
image_size = (250, 250)

# 读取训练图片并存储为列表
image_paths = [os.path.join(dataset_path, f) for f in os.listdir(dataset_path) if os.path.splitext(f)[1] == '.jpg']
training_images = [np.array(Image.open(p).convert('L')) for p in image_paths]

# 将每张图像存储为矩阵并组成列表
training_image_matrices = [img.reshape(image_size) for img in training_images]

# 将每个图像矩阵展平为向量
training_image_vectors = [img.flatten() for img in training_image_matrices]
training_image_array = np.array(training_image_vectors)

# 计算所有训练图像向量的平均向量
mean_face = np.mean(training_image_array, axis=0)

# 从每个图像向量中减去平均向量,得到去均值的人脸向量
demeaned_faces = training_image_array - mean_face

from sklearn.decomposition import PCA

# 计算协方差矩阵并进行PCA降维
pca = PCA(n_components=50)
pca.fit(demeaned_faces)
eigenfaces = pca.components_

# 将训练图像投影到特征脸空间,得到每个人脸的表示
training_faces_pca = pca.transform(demeaned_faces)

# 保存PCA模型和平均脸
import pickle
with open('pca_model.pkl', 'wb') as f:
    pickle.dump(pca, f)
np.save('mean_face.npy', mean_face)
np.save('training_faces_pca.npy', training_faces_pca)


