from sklearn.decomposition import PCA
import numpy as np
import os
from PIL import Image
import pickle

# 设置数据路径和图片数量
dataset_path = r"C:\Users\34800\Desktop\3790 essay\training_dataset"
image_size = (250, 250)

# 加载所有训练图像并转为灰度图
image_paths = [os.path.join(dataset_path, f) for f in os.listdir(dataset_path) if os.path.splitext(f)[1] == '.jpg']
images = [np.array(Image.open(p).convert('L')).flatten() for p in image_paths]
images = np.array(images)

# 应用PCA降维
n_components = 50
pca = PCA(n_components=n_components)
images_transformed = pca.fit_transform(images)
images_inv_transformed = pca.inverse_transform(images_transformed)
mean_face = np.mean(images_inv_transformed, axis=0)

# 保存PCA模型和平均脸
with open('pca_model_v3.pkl', 'wb') as f:
    pickle.dump(pca, f)
np.save('mean_face_v3.npy', mean_face)

# 保存图像转换结果以便后续测试
np.save('images_inv_transformed_v3.npy', images_inv_transformed)

