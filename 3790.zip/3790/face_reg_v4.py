# training_system.py

import numpy as np
import os
from PIL import Image

def load_training_faces(directory):
    faces = []
    for filename in os.listdir(directory):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            image = Image.open(os.path.join(directory, filename))
            face = np.asarray(image, dtype=np.float64)
            faces.append(face)
    return faces

def flatten_face(face):
    return face.reshape(-1)

def calculate_mean_face(faces):
    return np.mean(faces, axis=0)

def calculate_demean_faces(faces, mean_face):
    return [face - mean_face for face in faces]

def calculate_tensor_product(face):
    return np.outer(face, face)

def calculate_covariance(tensor_products):
    return np.mean(tensor_products, axis=0)

def pca(covariance, k):
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    sorted_indices = np.argsort(eigenvalues)[::-1]
    sorted_eigenvectors = eigenvectors[:, sorted_indices]
    return sorted_eigenvectors[:, :k]

# ...

def project_face(face, principal_components, mean_face):
    centered_face = face - mean_face
    # Apply PCA to reduce dimensionality
    reduced_face = np.dot(principal_components.T, centered_face)
    return reduced_face

# ...


# Step 1: Load training faces
training_directory = "C:\\Users\\34800\\Desktop\\3790 essay\\training_dataset"
training_faces = load_training_faces(training_directory)

# Step 2: Dissect each training face
# (Done in step 1)

# Step 3: Flatten faces
flattened_faces = [flatten_face(face) for face in training_faces]

# Step 4: Calculate mean face
mean_face = calculate_mean_face(flattened_faces)

# Step 5: Calculate demean faces
demean_faces = calculate_demean_faces(flattened_faces, mean_face)

# Step 6: Calculate tensor products
# First, apply PCA to reduce dimensionality
k = 100  # Choose the number of principal components
principal_components = pca(covariance, k)
reduced_demean_faces = [np.dot(principal_components.T, face) for face in demean_faces]

# Then, calculate tensor products
tensor_products = [calculate_tensor_product(face) for face in reduced_demean_faces]

# Step 7: Calculate covariance
covariance = calculate_covariance(tensor_products)

# PCA for dimensionality reduction
k = 50  # Choose the number of principal components
principal_components = pca(covariance, k)

# Save mean face and principal components
np.save("mean_face.npy", mean_face)
np.save("principal_components.npy", principal_components)
