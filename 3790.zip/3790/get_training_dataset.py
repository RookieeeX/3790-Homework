import os
import random
import shutil


def select_and_copy_photos(source_folder, destination_folder, num_photos=50):
    # 获取源文件夹下所有子文件夹的路径
    subfolders = [os.path.join(source_folder, name) for name in os.listdir(source_folder) if
                  os.path.isdir(os.path.join(source_folder, name))]

    # 遍历子文件夹并选择照片
    selected_photos = []
    for folder in subfolders:
        photos_in_folder = [os.path.join(folder, name) for name in os.listdir(folder) if
                            os.path.isfile(os.path.join(folder, name))]
        selected_photos.extend(random.sample(photos_in_folder, min(num_photos, len(photos_in_folder))))

    # 复制选定的照片到目标文件夹
    for photo in selected_photos:
        if len(os.listdir(destination_folder)) >= num_photos:
            break
        shutil.copy(photo, destination_folder)


# 源文件夹和目标文件夹的路径
source_folder_path = r"C:\Users\34800\Desktop\3790 essay\archive\lfw_funneled"
destination_folder_path = r"C:\Users\34800\Desktop\3790 essay\training_dataset"

# 选择并复制照片
select_and_copy_photos(source_folder_path, destination_folder_path)
