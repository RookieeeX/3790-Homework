import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.collocations import BigramAssocMeasures, BigramCollocationFinder
from nltk import FreqDist
from nltk.tokenize import RegexpTokenizer

nltk.download('punkt')
nltk.download('stopwords')

# 读取数据
file_path = 'C:\\Users\\34800\\Desktop\\3790 essay\\archive\\Womens Clothing E-Commerce Reviews.csv'
data = pd.read_csv(file_path)

# 提取评论文本列
reviews = data['Review Text'].dropna()  # 删除任何空值

# 文本清洗和分词
tokenizer = RegexpTokenizer(r'\w+')
tokens_list = [tokenizer.tokenize(review.lower()) for review in reviews]

# 移除停用词
stop_words = set(stopwords.words('english'))
filtered_tokens = [[word for word in tokens if not word in stop_words] for tokens in tokens_list]

# 创建bigram finder
bigram_measures = BigramAssocMeasures()
finder = BigramCollocationFinder.from_documents(filtered_tokens)

# 使用频率作为度量找到top 10的bigram
top_bigrams = finder.nbest(bigram_measures.raw_freq, 10)  # 获取频率最高的前10个bigrams
print(top_bigrams)

# 使用互信息得分
scored_bigrams = finder.score_ngrams(bigram_measures.pmi)
top_scored_bigrams = sorted(scored_bigrams, key=lambda x: x[1], reverse=True)[:10]
print("Top 10 bigrams by Mutual Information Scores:")
for bigram, score in top_scored_bigrams:
    print(f"{bigram}: {score}")


#我的训练集是Women's E-Commerce Clothing Reviews，存在C:\Users\34800\Desktop\3790 essay\archive\Womens Clothing E-Commerce Reviews.csv中，
#文件中的E列保存的是Review Text（第一行中是行标题），这应该是我们需要的内容。训练集中数据很多，你根据情况选择合适数量的数据来完成相应代码。
