from sklearn.decomposition import PCA
import numpy as np
import os
import matplotlib.pyplot as plt
from PIL import Image

# 设置数据路径和图片数量
dataset_path = r"C:\Users\34800\Desktop\3790 essay\training_dataset"
image_size = (250, 250)

# 读取所有图片并转为灰度图
image_paths = [os.path.join(dataset_path, f) for f in os.listdir(dataset_path) if os.path.splitext(f)[1] == '.jpg']
images = [np.array(Image.open(p).convert('L')).flatten() for p in image_paths]
images = np.array(images)

# 应用PCA降维
n_components = 50
pca = PCA(n_components=n_components)
images_transformed = pca.fit_transform(images)

# 计算逆变换，以便将降维的数据变换回原始维度空间
images_inv_transformed = pca.inverse_transform(images_transformed)

# 计算平均人脸（在原始空间中）
mean_face = np.mean(images_inv_transformed, axis=0)

# 显示平均人脸和前三个特征脸（主成分）
fig, ax = plt.subplots(1, 4, figsize=(10, 2.5))
ax[0].imshow(mean_face.reshape(image_size), cmap='gray')
ax[0].set_title('Mean Face')
ax[0].axis('off')

for i in range(3):
    eigenface = pca.components_[i].reshape(image_size)
    ax[i+1].imshow(eigenface, cmap='gray')
    ax[i+1].set_title(f'Eigenface {i + 1}')
    ax[i+1].axis('off')

plt.show()