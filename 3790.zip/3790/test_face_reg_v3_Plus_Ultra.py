import numpy as np
import os
from PIL import Image
import pickle
import random
import matplotlib.pyplot as plt

# 加载模型和平均脸
with open('pca_model.pkl', 'rb') as f:
    pca = pickle.load(f)
mean_face = np.load('mean_face.npy')


def load_images_from_folder(folder):
    """从给定文件夹加载图像,转换为灰度并展开为一维数组"""
    image_paths = [os.path.join(folder, f) for f in os.listdir(folder) if os.path.splitext(f)[1] == '.jpg']
    images = [np.array(Image.open(image_path).convert('L')).flatten() for image_path in image_paths]
    return np.array(images), image_paths


def is_face_recognized(test_image, pca, mean_face, threshold=0.6):
    """确定测试图像是否能通过训练的PCA模型被识别,使用重建误差"""
    test_image_demeaned = test_image - mean_face
    test_image_transformed = pca.transform(test_image_demeaned.reshape(1, -1))
    test_image_reconstructed = pca.inverse_transform(test_image_transformed)
    reconstruction_error = np.linalg.norm(test_image_demeaned - test_image_reconstructed)
    return reconstruction_error < threshold


def evaluate_recognition(test_images, pca, mean_face, threshold):
    """评估一组图像的识别正确率"""
    correct_recognitions = 0
    for test_image in test_images:
        if is_face_recognized(test_image, pca, mean_face, threshold):
            correct_recognitions += 1
    return correct_recognitions / len(test_images)


# 设置训练数据集和随机测试集路径
training_dataset_path = r"C:\Users\34800\Desktop\3790 essay\training_dataset"
rand_testing_dataset_path = r"C:\Users\34800\Desktop\3790 essay\rand_testing_dataset"

# 加载训练数据集
training_images, training_image_paths = load_images_from_folder(training_dataset_path)

# 设置随机测试的次数
num_tests = 5
accuracies = []

for i in range(num_tests):
    print(f"Random Test {i + 1}:")

    # 随机选择10张照片作为测试集
    test_indices = random.sample(range(len(training_images)), 10)
    test_images = training_images[test_indices]
    test_image_paths = [training_image_paths[i] for i in test_indices]

    # 将随机选择的照片保存到指定文件夹
    for path in test_image_paths:
        img = Image.open(path)
        img.save(os.path.join(rand_testing_dataset_path, os.path.basename(path)))

    # 评估识别正确率
    threshold = 0.6
    accuracy = evaluate_recognition(test_images, pca, mean_face, threshold)
    accuracies.append(accuracy)

    print(f"Recognition Accuracy: {accuracy * 100:.2f}%\n")

# 绘制准确率图表
plt.figure(figsize=(8, 6))
plt.plot(range(1, num_tests + 1), accuracies, marker='o')
plt.xlabel('Random Test')
plt.ylabel('Recognition Accuracy')
plt.title('Face Recognition Accuracy for Random Tests')
plt.xticks(range(1, num_tests + 1))
plt.ylim(0, 1)
plt.grid()
plt.show()
