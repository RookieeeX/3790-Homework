import time

# 开始时间
start_time = time.time()

import pandas as pd
import nltk
from nltk.collocations import BigramAssocMeasures, BigramCollocationFinder
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

nltk.download('punkt')
nltk.download('stopwords')

# 加载数据集
file_path = r'C:\Users\34800\Desktop\3790 essay\archive\Womens Clothing E-Commerce Reviews.csv'
data = pd.read_csv(file_path)

# 选择Review Text列
texts = data['Review Text'].dropna()  # 删除缺失值

# Tokenization and cleaning
tokens_list = [word_tokenize(text.lower()) for text in texts if isinstance(text, str)]
clean_tokens_list = [[word for word in tokens if word.isalpha() and word not in stopwords.words('english')]
                    for tokens in tokens_list]

# 将所有reviews的词汇并入一个大的list
all_tokens = [word for tokens in clean_tokens_list for word in tokens]
bigram_measures = BigramAssocMeasures()
finder = BigramCollocationFinder.from_words(all_tokens)

# 计算频率
bigram_freq = finder.ngram_fd
print(f'Most common bigrams: {bigram_freq.most_common(10)}')

# 结束时间
end_time = time.time()

# 输出运行时长
print(f"Runtime of the script is {end_time - start_time} seconds")
