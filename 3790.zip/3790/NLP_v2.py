import pandas as pd
import nltk
from nltk.collocations import BigramAssocMeasures, BigramCollocationFinder
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import Counter
import numpy as np
from scipy import stats

nltk.download('punkt')
nltk.download('stopwords')

# 加载数据集
file_path = r'C:\Users\34800\Desktop\3790 essay\archive\Womens Clothing E-Commerce Reviews.csv'
data = pd.read_csv(file_path)

# 选择Review Text列
texts = data['Review Text'].dropna()  # 删除缺失值

# Tokenization and cleaning
tokens_list = [word_tokenize(text.lower()) for text in texts if isinstance(text, str)]
clean_tokens_list = [[word for word in tokens if word.isalpha() and word not in stopwords.words('english')]
                    for tokens in tokens_list]

# 将所有reviews的词汇并入一个大的list
all_tokens = [word for tokens in clean_tokens_list for word in tokens]
bigram_measures = BigramAssocMeasures()
finder = BigramCollocationFinder.from_words(all_tokens)

# 计算频率
bigram_freq = finder.ngram_fd
print(f'Most common bigrams: {bigram_freq.most_common(10)}')

# 搭配词频率列表
freq_values = list(bigram_freq.values())
mean_freq = np.mean(freq_values)
variance_freq = np.var(freq_values)

print(f'Mean frequency: {mean_freq}')
print(f'Variance of frequency: {variance_freq}')

# 生成两个不同大小的子集bigram频率数据
subset1 = finder.ngram_fd.items()  # 将整个finder的结果作为一个子集
finder.apply_freq_filter(3)  # 过滤掉频率小于3的bigram
subset2 = finder.ngram_fd.items()

freq1 = [freq for _, freq in subset1]
freq2 = [freq for _, freq in subset2]

# 执行t检验
t_stat, p_value = stats.ttest_ind(freq1, freq2, equal_var=False)
print(f"T-statistic: {t_stat}, P-value: {p_value}")

# 计算互信息
scored = finder.score_ngrams(bigram_measures.pmi)
print(f'Top 10 bigrams by PMI: {sorted(scored, key=lambda t: (-t[1], t[0]))[:10]}')
