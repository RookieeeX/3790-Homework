import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import pickle
import os


def load_images_from_folder(folder, image_size):
    """从指定文件夹加载图像并转换为灰度"""
    image_paths = [os.path.join(folder, f) for f in os.listdir(folder) if os.path.splitext(f)[1] == '.jpg']
    images = [np.array(Image.open(image_path).convert('L')).flatten() for image_path in image_paths]
    return np.array(images)


# 加载PCA模型和平均脸
with open('pca_model.pkl', 'rb') as f:
    pca = pickle.load(f)
mean_face = np.load('mean_face.npy')

# 设置测试数据集的路径
test_dataset01_path = r"C:\Users\34800\Desktop\3790 essay\testing_dataset01"
test_dataset02_path = r"C:\Users\34800\Desktop\3790 essay\testing_dataset02"

# 载入测试数据集
test_images01 = load_images_from_folder(test_dataset01_path, (250, 250))
test_images02 = load_images_from_folder(test_dataset02_path, (250, 250))

# 用PCA模型对测试数据集进行特征转换
test_images_transformed01 = pca.transform(test_images01)
test_images_transformed02 = pca.transform(test_images02)

# 逆变换以获取重建图像
test_images_reconstructed01 = pca.inverse_transform(test_images_transformed01)
test_images_reconstructed02 = pca.inverse_transform(test_images_transformed02)


# 定义函数来显示测试结果
def display_images(original, reconstructed, title):
    plt.figure(figsize=(10, 5))
    for i in range(len(original)):
        plt.subplot(2, len(original), i + 1)
        plt.imshow(original[i].reshape(250, 250), cmap='gray')
        plt.title('Original')
        plt.axis('off')

        plt.subplot(2, len(original), i + 1 + len(original))
        plt.imshow(reconstructed[i].reshape(250, 250), cmap='gray')
        plt.title('Reconstructed')
        plt.axis('off')
    plt.suptitle(title)
    plt.show()


# 显示测试集01的结果
display_images(test_images01, test_images_reconstructed01, "Test Dataset 01 Results")

# 显示测试集02的结果
display_images(test_images02, test_images_reconstructed02, "Test Dataset 02 Results")
