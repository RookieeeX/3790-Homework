import numpy as np
import os
from PIL import Image
import pickle
import random
import matplotlib.pyplot as plt

# 加载模型和平均脸
with open('pca_model_v3.pkl', 'rb') as f:
    pca = pickle.load(f)
mean_face = np.load('mean_face_v3.npy')


def load_images_from_folder(folder):
    """从给定文件夹加载图像、转换为灰度并展开为一维数组"""
    image_paths = [os.path.join(folder, f) for f in os.listdir(folder) if os.path.splitext(f)[1] == '.jpg']
    images = [np.array(Image.open(image_path).convert('L')).flatten() for image_path in image_paths]
    return np.array(images)


def is_face_recognized(test_image, pca, mean_face, threshold=0.8):
    """确定测试图像是否能通过训练的PCA模型被识别，使用重建误差"""
    test_image_transformed = pca.transform(test_image.reshape(1, -1))
    test_image_reconstructed = pca.inverse_transform(test_image_transformed)
    reconstruction_error = np.linalg.norm(test_image - test_image_reconstructed)
    return reconstruction_error < threshold


def evaluate_recognition(test_images, pca, mean_face, threshold):
    """评估一组图像的识别正确率"""
    correct_recognitions = 0
    for test_image in test_images:
        if is_face_recognized(test_image, pca, mean_face, threshold):
            correct_recognitions += 1
    return correct_recognitions / len(test_images)


def perform_random_tests(repeats=5, num_samples=10, threshold=0.8):
    accuracies = []
    for _ in range(repeats):
        # 随机选择测试图像
        all_images = load_images_from_folder(r"C:\Users\34800\Desktop\3790 essay\training_dataset")
        test_indices = random.sample(range(len(all_images)), num_samples)
        test_images = all_images[test_indices]

        # 评估识别正确率
        accuracy = evaluate_recognition(test_images, pca, mean_face, threshold)
        accuracies.append(accuracy)
    return accuracies


# 设置参数
repeats = 5
num_samples = 10
threshold = 0.8

# 执行随机测试并获取准确率
accuracies = perform_random_tests(repeats, num_samples, threshold)

# 绘制每次测试的准确率
plt.figure()
plt.bar(range(1, repeats + 1), [acc * 100 for acc in accuracies])
plt.xlabel('Test Run')
plt.ylabel('Accuracy (%)')
plt.title('Randomized Face Recognition Accuracy')
plt.show()
