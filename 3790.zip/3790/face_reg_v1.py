import numpy as np
import os
import matplotlib.pyplot as plt
from PIL import Image

# 配置数据集路径
dataset_path = r"C:\Users\34800\Desktop\3790 essay\training_dataset"
image_size = (250, 250)  # 图片的大小

# 从文件夹中读取所有图片
image_paths = [os.path.join(dataset_path, f) for f in os.listdir(dataset_path) if os.path.splitext(f)[1] == '.jpg']

# 确保恰好有50张图片
if len(image_paths) != 50:
    print("图片数量不是50张，请检查数据集！")
    exit()

# 读取图片，转为灰度图并并 Flatten 成一维
flat_images = []
for image_path in image_paths:
    img = Image.open(image_path).convert('L')
    img_data = np.array(img).flatten()
    flat_images.append(img_data)

# 创建矩阵 P，每一行是一个 Flattened 图片
P = np.array(flat_images).astype('float32')

# 计算平均人脸
mean_face = np.mean(P, axis=0)

# 获取去平均化的人脸
demeaned_faces = P - mean_face

# 计算协方差矩阵
covariance_matrix = np.cov(demeaned_faces.T)

# 显示平均人脸和前几个特征脸
fig, ax = plt.subplots(1, 4, figsize=(10, 2.5))
ax[0].imshow(mean_face.reshape(image_size), cmap='gray')
ax[0].set_title('Mean Face')
ax[0].axis('off')

# 求解特征值和特征向量
eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)

# 显示前三个特征脸
for i in range(3):
    eigenvector = eigenvectors[:, -1-i]
    eigenface = eigenvector.reshape(image_size)
    ax[i+1].imshow(eigenface, cmap='gray')
    ax[i+1].set_title(f'Eigenface {i+1}')
    ax[i+1].axis('off')

plt.show()